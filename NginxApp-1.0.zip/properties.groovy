
class ExecutionContext  { 
	def map=null
        def ExecutionContext(args,defaults=null){
                def map=[:]
		if (defaults != null) { map = defaults }
                for(def arg:args){
                        def index=arg.indexOf("=")
                        def k=arg.substring(0,index)
                        def v=arg.substring(index+1,arg.size())
                        map[k]=v
                }
                this.map=map
        }

}


