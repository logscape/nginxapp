
proxyStatsPage="http://Username:Password@10.28.1.159:1936" 
username="Username"
password="Password"
def  conn = new URL(proxyStatsPage).openConnection()
def authString="$username:$password".getBytes().encodeBase64().toString() 
conn.setRequestProperty("Authorization","Basic ${authString}")
conn.connect()
html= conn.getContent().getText() 

def parser= new org.cyberneko.html.parsers.SAXParser()
parser.setFeature('http://xml.org/sax/features/namespaces', false)
html2="""
<HTML>
	<BODY 
		<p> bob </p> 
		<table>
			<tr class="frontend">
				<td> one </td>
				<td> up </td> 
				<td>  </td> 
			</tr>
	</BODY>
</HTML>
""" 
def page = new XmlParser(parser).parseText(html)

nodes=page.depthFirst().findAll { it.@class == 'frontend' || it.@class == 'titre'  } 
nodes.each {
	def row = it.collect{   it.text()  }
	println row.join(" | ") 
}
/*
nodes=page.'**'.findAll { it.@class == 'frontend' }
nodes[1].each {
	println it.value() 
}
def data = page.depthFirst().tr.'@class'.grep { it != null && it.contains("frontend") }

//'@class'.grep { it !=null && it.contains("stats/")  == true  }
data.each { println it }
*/
