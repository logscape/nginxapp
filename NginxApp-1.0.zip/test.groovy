import groovyx.net.http.HTTPBuilder;

def url="http://10.28.1.159:1739" 
def http = new HTTPBuilder(url)
def html=http.get(path:'/' ); 
println html 


