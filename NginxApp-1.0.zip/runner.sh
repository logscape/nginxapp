#!/bin/sh
export master=`hostname`
export port=27017
export wait=1
export rows=1
for kv in $(echo $*);do
	kv=`echo $kv | sed -e 's/=/ /g' `
	key=`echo $kv | awk '{print $1}'`
	pair=`echo $kv | awk '{print $2}'`

        case $key  in
                *\[|\.|\&|,|;|:*        ) key="ignore_key";;
                *,*     ) key="ignore_key";;
                *]*     ) key="ignore_key";;
                *:*     ) key="ignore_key";;
                *.*     ) key="ignore_key";;
                [0-9]*  ) key="ignore_key";;
                ""      ) key="empty_key";;

        esac


	export $key="$pair"
done 
cd $WorkingDirectory 
exec $COMMAND
